<?php
	include('includes/header.php');

?>
<!--our services-->
<section id="services">
	<div class="jumbotron">
		<div class="container">
			<!--categories-->
		</div>
	</div>
</section>
<!--contact us-->
<section id="contact">
	<div class="jumbotron">
		<div class="container">
			<div class="form-row">
				<div class="col-md-5">
					<form action="" method="POST" class="contact-form">
						<h6 class="">phone: 0748-637-080</h6>
						<h6 class="">Email: ondari.mike@gmail.com</h6>
						<h6 class="">facebook: facebook</h6>
						<h6 class="">twitter: twitter-080</h6>
						<h6 class="">instagram: instagram</h6>
						<h6 class="">facebook: facebook</h6>
					</form>
				</div>
				<div class="col-md-5">
					<!--map-->
				</div>
			</div>
		</div6
	</div>
</section>

<?php
	include('includes/footer.php');
?>