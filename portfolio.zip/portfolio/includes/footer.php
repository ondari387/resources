	<!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container mb-0">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; MikeDesigns 2020</span>
          </div>
        </div>
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.js"></script>
      </footer>
      	<!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
</body>

</html>